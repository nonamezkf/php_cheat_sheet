<html>

	<head>
		<title>Form Get</title>
	</head>
	
	<body>
	
		<form action="tangkapGet.php" method="GET">
			Nama :
			<input type="text" name="nama" />
			
			<br/>
			
			<input type="submit" value="kirim" />
		
		</form>
		
	</body>
	
</html>