<html>

	<head>
		<title>Form Post</title>
	</head>
	
	<body>
	
		<form action="tangkapPost.php" method="POST">
			Nama :
			<input type="text" name="nama" />
			
			<br/>
			
			<input type="submit" value="kirim" />
		
		</form>
		
	</body>
	
</html>