<?php
    $a = 10;
    $b = 20;
    $c = 30;
    $d = 10;
 
    if($a > $b)
    {
        echo "Nilai $a lebih besar dari nilai $b";
    }
    elseif($a == $b)
    {
        echo "Nilai $a sama dengan nilai $b";
    }
    elseif($c == $b)
    {
        echo "Nilai $c sama dengan nilai $b";
    }
    else
    {
        echo "semua kondisi diatas salah";
    }
?>