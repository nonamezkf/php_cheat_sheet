<?php

	echo "<a href='tangkapGet.php?nama=wegodev'>isi dari variable nama adalah wegodev</a>";
	
?>	