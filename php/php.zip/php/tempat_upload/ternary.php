<?php
    $a = 10;
    $txt = ""; //membuat variable kosong
     
    //MEMERIKSA APAKAH NILAI a TIDAK SAMA DENGAN NILAI 10
    //BILA NILAI a tidak sama maka akan mencetak  "Nilai a tidak sama dengan nilai 10"
    $a != 10 ? $txt = "Nilai a tidak sama dengan nilai 10" : $txt = "Nilai a sama dengan nilai 10";
     
    echo $txt;
?>