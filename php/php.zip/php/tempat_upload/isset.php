<?php

	$buah = "Apel";
	$kendaraan = "Mobil";
	
	echo "Hasil Variable Buah :" . isset($buah);
	
	echo "<br/>";
	
	echo "Hasil Variable Kendaraan :" . isset($kendaraan);
	
	echo "<br/>";
	
	echo "Hasil Variable Minuman :" . isset($minuman);
	
?>	