<html>

	<head>
	
		<title>Form Upload</title>
	
	</head>
	
	<body>
	
		<form action="upload.php" method="POST" enctype="multipart/form-data">
		
			<input type="file" name="file" />
			
			<br/>
			
			<input type="submit" value="kirim" />
		
		</form>
		
	</body>
	
</html>	