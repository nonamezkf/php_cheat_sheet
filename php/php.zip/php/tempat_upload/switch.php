<?php

    $a = 10;
     
    switch ($a) {
        case 30:
            echo "$a sama dengan 30";
            break;
        case 10:
            echo "$a sama dengan 10";
            break;
        case 20:
            echo "$a sama dengan 20";
            break;
    }
         
?>