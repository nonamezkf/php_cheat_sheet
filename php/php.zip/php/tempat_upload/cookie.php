<?php

	setcookie("negara", "Indonesia");
	
	echo $_COOKIE['negara'];
	
?>	