<?php    
    $buah = "Apel";
    $minuman = "Teh";
    $kendaraan;
      
    echo "Hasil Variable buah : " . empty($buah);
 
    echo "<br/>";
    
    echo "Hasil Variable kendaraan : " . empty($kendaraan);
 
    echo "<br/>";
     
    echo "Hasil Variable minuman : " . !empty($minuman);
?>