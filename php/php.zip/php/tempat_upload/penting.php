<?php

	$negara = "Indonesia";
	$ibu_kota = "Jakarta";
	
?>