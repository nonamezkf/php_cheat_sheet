<?php

	session_start();
	
	echo $_SESSION['negara'];
	
	echo "<br/>";
	
	echo $_SESSION['ibu_kota'];
	
?>	