<?php

	$nama[0] = "Rudi";
	$nama[1] = "Desta";
	$nama[2] = "Mike";
	
	$JenisKelamin = array("C" => "Cewek", "L" => "Laki- Laki");
	
	$olahraga = array("Bola", "Basket", "Badminton", "Tenis Meja");
	
	echo $nama[1];

	echo "<br/>";
	
	echo $JenisKelamin["C"];
	
	echo "<br/>";
	
	echo @olahraga[2];
	
?>