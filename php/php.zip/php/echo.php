<?php

	$buah = "Nanas";
	
	echo "Apel <br/>";
	echo $buah;
	
?>