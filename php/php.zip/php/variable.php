<?php

	$nilai1 = 10;
	$nilai2 = 30;
	$nilai3 = $nilai1 + $nilai2;
	
	echo "Variable Nilai 1 = $nilai1 <br/>";
	echo "Variable Nilai 2 = $nilai2 <br/>";
	echo "Variable Nilai 3 adalah hasil dari nilai 1 + nilai 2 = $nilai3";
	
?>
	