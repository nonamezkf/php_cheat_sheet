<?php

	define("nilai1", 10);
	
	echo nilai1;
	
?>