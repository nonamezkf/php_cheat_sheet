<?php

	include_once("penting.php");
	
	echo $negara;
	echo "<br/>";
	echo $ibu_kota;

?>